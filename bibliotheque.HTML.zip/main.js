// Ajouter des événements de clic sur les boutons
document.querySelectorAll('.btn-read').forEach(button => {
    button.addEventListener('click', function() {
        alert('Lecture du livre en cours...');
        // Code pour afficher la lecture en ligne
    });
});

document.querySelectorAll('.btn-download').forEach(button => {
    button.addEventListener('click', function() {
        alert('Téléchargement du livre en cours...');
        // Code pour le téléchargement
    });
});